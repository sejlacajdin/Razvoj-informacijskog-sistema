create database ISUpravljanjeProjektom
use ISUpravljanjeProjektom
go

CREATE TABLE Aktivnost 
(
    AktivnostID INTEGER NOT NULL,
    Naziv NVARCHAR(20) NOT NULL,
    Opis NVARCHAR(50) NOT NULL,
    Status NVARCHAR(15) NOT NULL,
    Prioritet NVARCHAR(10) NOT NULL,
    Status_StatusID INTEGER NOT NULL,
    Prioritet_PrioritetID INTEGER NOT NULL,
    Projekat_ProjekatID INTEGER NOT NULL
);


CREATE TABLE ClanTima 
(
    OsobaID INTEGER NOT NULL,
    Ime NVARCHAR(30) NOT NULL,
    Prezime NVARCHAR(30) NOT NULL,
    Lozinka NVARCHAR(30) NOT NULL,
    Email NVARCHAR(30) NOT NULL,
    Uloga_UlogaID INTEGER NOT NULL
);


CREATE TABLE ClanTimaAktivnost 
(
    ClanTima_OsobaID INTEGER NOT NULL,
    Aktivnost_AktivnostID INTEGER NOT NULL
);


CREATE TABLE ClanTimProjekat 
(
    ClanTima_OsobaID INTEGER NOT NULL,
    ProjektniTim_TimID INTEGER NOT NULL,
    Projekat_ProjekatID INTEGER NOT NULL
);


CREATE TABLE Donatori 
(
    DonatorID INTEGER NOT NULL,
    NazivDonatora NVARCHAR(30) NOT NULL,
    Adresa NVARCHAR(30) NULL,
    Telefon NVARCHAR(15) NULL,
    Email NVARCHAR(20) NULL,
    OpisDjelatnosti NVARCHAR(50) NOT NULL,
    ClanTima_OsobaID INTEGER NOT NULL
);


CREATE TABLE DonatoriProjekat 
(
    Donatori_DonatorID INTEGER NOT NULL,
    Projekat_ProjekatID INTEGER NOT NULL
);


CREATE TABLE Izvje�taj 
(
    IzvjestajID INTEGER NOT NULL,
    Datum DATETIME NOT NULL,
    Opis TEXT NOT NULL,
    RepozitorijIzvjest_RepozitorijIzvjestajaID INTEGER NOT NULL
);


CREATE TABLE IzvjestajClan 
(
    Izvje�taj_IzvjestajID INTEGER NOT NULL,
    ClanTima_OsobaID INTEGER NOT NULL
);


CREATE TABLE IzvjestajMenadzer 
(
    Izvje�taj_IzvjestajID INTEGER NOT NULL,
    ProjektniMenadzer_MenadzerID INTEGER NOT NULL
);


CREATE TABLE PlanerAktivnosti 
(
    PlanerID INTEGER NOT NULL,
    Naziv NVARCHAR(20) NOT NULL,
    Projekat_ProjekatID INTEGER NOT NULL
);


CREATE TABLE Prioritet 
(
    PrioritetID INTEGER NOT NULL,
    Naziv NVARCHAR(10) NOT NULL
);


CREATE TABLE Projekat 
(
    ProjekatID INTEGER NOT NULL,
    Naziv_projekta NVARCHAR(20) NOT NULL,
    Opis TEXT NOT NULL,
    DatumPocetka DATETIME NOT NULL,
    DatumZavrsetka DATETIME NOT NULL,
    Ciljevi TEXT NULL,
    Snage NVARCHAR(50) NULL,
    Slabosti NVARCHAR(50) NULL,
    Sanse NVARCHAR(50) NULL,
    Prijetnje NVARCHAR(50) NULL,
    RepozitorijProjeka_RepozitorijProjekataID INTEGER NOT NULL,
    ProjektniMenadzer_MenadzerID INTEGER NOT NULL,
    PlanerAktivnosti_PlanerID INTEGER NOT NULL
);


CREATE TABLE ProjektniMenadzer 
(
    MenadzerID INTEGER NOT NULL,
    Ime NVARCHAR(20) NOT NULL,
    Prezime NVARCHAR(20) NOT NULL,
    Email NVARCHAR(20) NOT NULL,
    Lozinka NVARCHAR(20) NOT NULL,
    Projekat_ProjekatID INTEGER NOT NULL
);


CREATE TABLE ProjektniTim 
(
    TimID INTEGER NOT NULL,
    NazivTima NVARCHAR(30) NOT NULL
);


CREATE TABLE RepozitorijIzvjest 
(
    RepozitorijIzvjestajaID INTEGER NOT NULL,
    Naziv NVARCHAR(20) NOT NULL
);


CREATE TABLE RepozitorijProjeka 
(
    RepozitorijProjekataID INTEGER NOT NULL,
    Naziv NVARCHAR(20) NOT NULL
);


CREATE TABLE Resursi 
(
    ResursID INTEGER NOT NULL,
    Naziv NVARCHAR(30) NOT NULL,
    Cijena MONEY NOT NULL,
    Opis NVARCHAR(60) NULL
);


CREATE TABLE ResursiZadatak 
(
    UkupniTroskovi MONEY NULL,
    Resursi_ResursID INTEGER NOT NULL,
    Zadatak_ZadatakID INTEGER NOT NULL
);


CREATE TABLE Rizici 
(
    RizikID INTEGER NOT NULL,
    Opis TEXT NOT NULL,
    VrstaRizika NVARCHAR(20) NOT NULL,
    Utjecaj NVARCHAR(20) NOT NULL,
    Vjerovatnoca NVARCHAR(20) NOT NULL,
    Prevencija TEXT NOT NULL,
    Projekat_ProjekatID INTEGER NOT NULL
);


CREATE TABLE Status 
(
    StatusID INTEGER NOT NULL,
    Naziv NVARCHAR(20) NOT NULL
);


CREATE TABLE Uloga 
(
    UlogaID INTEGER NOT NULL,
    Naziv NVARCHAR NOT NULL
);


CREATE TABLE Zadatak 
(
    ZadatakID INTEGER NOT NULL,
    Naziv NVARCHAR(30) NOT NULL,
    DatumPocetka DATETIME NOT NULL,
    DatumZavrsetka DATETIME NOT NULL,
    PlanerAktivnosti_PlanerID INTEGER NOT NULL
);


ALTER TABLE ClanTimProjekat 
  ADD CONSTRAINT Clan_ProjektniTim_Projekat PRIMARY KEY (
    ClanTima_OsobaID, ProjektniTim_TimID, Projekat_ProjekatID)  ;
ALTER TABLE ResursiZadatak 
  ADD CONSTRAINT Resursi_Zadaci PRIMARY KEY (
    Resursi_ResursID, Zadatak_ZadatakID)  ;
ALTER TABLE ClanTimaAktivnost 
  ADD CONSTRAINT ClanTima_Aktivnost PRIMARY KEY (
    ClanTima_OsobaID, Aktivnost_AktivnostID)  ;
ALTER TABLE DonatoriProjekat 
  ADD CONSTRAINT Donatori_Projekat PRIMARY KEY (
    Donatori_DonatorID, Projekat_ProjekatID)  ;
ALTER TABLE IzvjestajMenadzer 
  ADD CONSTRAINT Izvjestaj_Menadzer PRIMARY KEY (
    Izvje�taj_IzvjestajID, ProjektniMenadzer_MenadzerID)  ;
ALTER TABLE IzvjestajClan 
  ADD CONSTRAINT Izvjestaj_Clan PRIMARY KEY (
    Izvje�taj_IzvjestajID, ClanTima_OsobaID)  ;
ALTER TABLE Aktivnost 
  ADD CONSTRAINT PK_Aktivnost_Primary_Key PRIMARY KEY (
    AktivnostID)  ;
ALTER TABLE ClanTima 
  ADD CONSTRAINT PK_ClanTima_Primary_Key PRIMARY KEY (
    OsobaID)  ;
ALTER TABLE Donatori 
  ADD CONSTRAINT PK_Donatori_Primary_Key PRIMARY KEY (
    DonatorID)  ;
ALTER TABLE Izvje�taj 
  ADD CONSTRAINT PK_Izvje�taj_Primary_Key PRIMARY KEY (
    IzvjestajID)  ;
ALTER TABLE PlanerAktivnosti 
  ADD CONSTRAINT PK_PlanerAktivnosti_Primary_Key PRIMARY KEY (
    PlanerID)  ;
ALTER TABLE Prioritet 
  ADD CONSTRAINT PK_Prioritet_Primary_Key PRIMARY KEY (
    PrioritetID)  ;
ALTER TABLE Projekat 
  ADD CONSTRAINT PK_Projekat_Primary_Key PRIMARY KEY (
    ProjekatID)  ;
ALTER TABLE ProjektniMenadzer 
  ADD CONSTRAINT PK_ProjektniMenadzer_Primary_Key PRIMARY KEY (
    MenadzerID)  ;
ALTER TABLE ProjektniTim 
  ADD CONSTRAINT PK_ProjektniTim_Primary_Key PRIMARY KEY (
    TimID)  ;
ALTER TABLE RepozitorijIzvjest 
  ADD CONSTRAINT PK_RepozitorijIzvjest_Primary_Key PRIMARY KEY (
    RepozitorijIzvjestajaID)  ;
ALTER TABLE RepozitorijProjeka 
  ADD CONSTRAINT PK_RepozitorijProjeka_Primary_Key PRIMARY KEY (
    RepozitorijProjekataID)  ;
ALTER TABLE Resursi 
  ADD CONSTRAINT PK_Resursi_Primary_Key PRIMARY KEY (
    ResursID)  ;
ALTER TABLE Rizici 
  ADD CONSTRAINT PK_Rizici_Primary_Key PRIMARY KEY (
    RizikID)  ;
ALTER TABLE Status 
  ADD CONSTRAINT PK_Status_Primary_Key PRIMARY KEY (
    StatusID)  ;
ALTER TABLE Uloga 
  ADD CONSTRAINT PK_Uloga_Primary_Key PRIMARY KEY (
    UlogaID)  ;
ALTER TABLE Zadatak 
  ADD CONSTRAINT PK_Zadatak_Primary_Key PRIMARY KEY (
    ZadatakID)  ;
ALTER TABLE Rizici
  ADD 
    FOREIGN KEY (Projekat_ProjekatID)
      REFERENCES Projekat;

ALTER TABLE ClanTima
  ADD 
    FOREIGN KEY (Uloga_UlogaID)
      REFERENCES Uloga;

ALTER TABLE Zadatak
  ADD 
    FOREIGN KEY (PlanerAktivnosti_PlanerID)
      REFERENCES PlanerAktivnosti
        ON DELETE CASCADE;

ALTER TABLE Projekat
  ADD 
    FOREIGN KEY (RepozitorijProjeka_RepozitorijProjekataID)
      REFERENCES RepozitorijProjeka
        ON DELETE CASCADE;

ALTER TABLE Projekat
  ADD 
    FOREIGN KEY (ProjektniMenadzer_MenadzerID)
      REFERENCES ProjektniMenadzer;

ALTER TABLE Projekat
  ADD 
    FOREIGN KEY (PlanerAktivnosti_PlanerID)
      REFERENCES PlanerAktivnosti;

ALTER TABLE Donatori
  ADD 
    FOREIGN KEY (ClanTima_OsobaID)
      REFERENCES ClanTima;

ALTER TABLE Izvje�taj
  ADD 
    FOREIGN KEY (RepozitorijIzvjest_RepozitorijIzvjestajaID)
      REFERENCES RepozitorijIzvjest;

ALTER TABLE Aktivnost
  ADD 
    FOREIGN KEY (Status_StatusID)
      REFERENCES Status;

ALTER TABLE Aktivnost
  ADD 
    FOREIGN KEY (Prioritet_PrioritetID)
      REFERENCES Prioritet;

ALTER TABLE Aktivnost
  ADD 
    FOREIGN KEY (Projekat_ProjekatID)
      REFERENCES Projekat
        ON DELETE CASCADE;

ALTER TABLE PlanerAktivnosti
  ADD 
    FOREIGN KEY (Projekat_ProjekatID)
      REFERENCES Projekat;

ALTER TABLE ProjektniMenadzer
  ADD 
    FOREIGN KEY (Projekat_ProjekatID)
      REFERENCES Projekat;

ALTER TABLE ClanTimProjekat
  ADD 
    FOREIGN KEY (ClanTima_OsobaID)
      REFERENCES ClanTima
        ON DELETE CASCADE;

ALTER TABLE ClanTimProjekat
  ADD 
    FOREIGN KEY (ProjektniTim_TimID)
      REFERENCES ProjektniTim
        ON DELETE CASCADE;

ALTER TABLE ClanTimProjekat
  ADD 
    FOREIGN KEY (Projekat_ProjekatID)
      REFERENCES Projekat;

ALTER TABLE ResursiZadatak
  ADD 
    FOREIGN KEY (Resursi_ResursID)
      REFERENCES Resursi
        ON DELETE CASCADE;

ALTER TABLE ResursiZadatak
  ADD 
    FOREIGN KEY (Zadatak_ZadatakID)
      REFERENCES Zadatak
        ON DELETE CASCADE;

ALTER TABLE ClanTimaAktivnost
  ADD 
    FOREIGN KEY (ClanTima_OsobaID)
      REFERENCES ClanTima
        ON DELETE CASCADE;

ALTER TABLE ClanTimaAktivnost
  ADD 
    FOREIGN KEY (Aktivnost_AktivnostID)
      REFERENCES Aktivnost
        ON DELETE CASCADE;

ALTER TABLE DonatoriProjekat
  ADD 
    FOREIGN KEY (Donatori_DonatorID)
      REFERENCES Donatori;

ALTER TABLE DonatoriProjekat
  ADD 
    FOREIGN KEY (Projekat_ProjekatID)
      REFERENCES Projekat;

ALTER TABLE IzvjestajMenadzer
  ADD 
    FOREIGN KEY (Izvje�taj_IzvjestajID)
      REFERENCES Izvje�taj;

ALTER TABLE IzvjestajMenadzer
  ADD 
    FOREIGN KEY (ProjektniMenadzer_MenadzerID)
      REFERENCES ProjektniMenadzer
        ON DELETE CASCADE;

ALTER TABLE IzvjestajClan
  ADD 
    FOREIGN KEY (Izvje�taj_IzvjestajID)
      REFERENCES Izvje�taj;

ALTER TABLE IzvjestajClan
  ADD 
    FOREIGN KEY (ClanTima_OsobaID)
      REFERENCES ClanTima
        ON DELETE CASCADE;



    

